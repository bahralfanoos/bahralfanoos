'use client';

import { motion } from 'framer-motion';
import Header from '../../components/Header';
import Footer from '../../components/Footer';

export default function Story() {
  const timelineEvents = [
    {
      year: '2008',
      title: 'Foundation',
      description: 'BAHR AL FANOOS Technical Services was established with a vision to provide exceptional technical solutions in Dubai.',
      image: 'https://readdy.ai/api/search-image?query=Modern%20office%20building%20establishment%2C%20professional%20business%20foundation%2C%20Dubai%20cityscape%2C%20corporate%20building%20exterior%2C%20contemporary%20architecture%2C%20business%20startup%20concept&width=400&height=300&seq=story1&orientation=landscape'
    },
    {
      year: '2009',
      title: 'First Major Project',
      description: 'Successfully completed our first major commercial installation project, establishing credibility in the Dubai market.',
      image: 'https://readdy.ai/api/search-image?query=First%20construction%20project%20completion%2C%20commercial%20building%20installation%20work%2C%20professional%20technicians%20working%2C%20milestone%20achievement%2C%20successful%20project%20delivery&width=400&height=300&seq=story2a&orientation=landscape'
    },
    {
      year: '2011',
      title: 'Equipment Investment',
      description: 'Invested in advanced tools and equipment to enhance service quality and efficiency across all technical operations.',
      image: 'https://readdy.ai/api/search-image?query=Advanced%20construction%20tools%20and%20equipment%2C%20modern%20technical%20machinery%2C%20professional%20workshop%20setup%2C%20quality%20tools%20investment%2C%20technical%20equipment%20upgrade&width=400&height=300&seq=story2b&orientation=landscape'
    },
    {
      year: '2013',
      title: 'Client Base Growth',
      description: 'Expanded client portfolio to include residential complexes, offices, and retail establishments throughout Dubai.',
      image: 'https://readdy.ai/api/search-image?query=Growing%20business%20portfolio%2C%20diverse%20client%20projects%2C%20residential%20and%20commercial%20buildings%2C%20expanding%20customer%20base%2C%20successful%20business%20growth&width=400&height=300&seq=story2c&orientation=landscape'
    },
    {
      year: '2015',
      title: 'Quality Certification',
      description: 'Achieved industry certifications and quality standards, reinforcing our commitment to professional excellence.',
      image: 'https://readdy.ai/api/search-image?query=Professional%20certification%20achievement%2C%20quality%20standards%20documentation%2C%20industry%20recognition%2C%20excellence%20certificate%2C%20professional%20accreditation&width=400&height=300&seq=story2d&orientation=landscape'
    },
    {
      year: '2017',
      title: 'Service Specialization',
      description: 'Developed specialized expertise in aluminum fabrication and glass installation, becoming known for precision work.',
      image: 'https://readdy.ai/api/search-image?query=Specialized%20aluminum%20and%20glass%20work%2C%20precision%20fabrication%2C%20expert%20craftsmanship%2C%20specialized%20technical%20skills%2C%20professional%20installation%20work&width=400&height=300&seq=story2e&orientation=landscape'
    },
    {
      year: '2018',
      title: '10-Year Milestone',
      description: 'Celebrated a decade of reliable service with over 500 completed projects and a reputation for excellence.',
      image: 'https://readdy.ai/api/search-image?query=Ten%20year%20business%20anniversary%20celebration%2C%20milestone%20achievement%2C%20successful%20company%20history%2C%20professional%20team%20celebration%2C%20business%20success%20story&width=400&height=300&seq=story2f&orientation=landscape'
    },
    {
      year: '2019',
      title: 'Team Expansion',
      description: 'Grew our expert team of skilled technicians and craftsmen to serve a wider range of technical services.',
      image: 'https://readdy.ai/api/search-image?query=Professional%20technical%20team%2C%20skilled%20workers%20with%20tools%2C%20teamwork%20in%20construction%2C%20diverse%20group%20of%20technicians%2C%20collaborative%20work%20environment%2C%20expertise%20and%20craftsmanship&width=400&height=300&seq=story2&orientation=landscape'
    },
    {
      year: '2020',
      title: 'Service Diversification',
      description: 'Expanded our services to include aluminum work, glass partitions, air conditioning, and comprehensive maintenance solutions.',
      image: 'https://readdy.ai/api/search-image?query=Modern%20aluminum%20and%20glass%20installation%2C%20professional%20technical%20services%2C%20construction%20work%20in%20progress%2C%20high-quality%20craftsmanship%2C%20modern%20building%20interior%20renovation&width=400&height=300&seq=story3&orientation=landscape'
    },
    {
      year: '2021',
      title: 'Quality Excellence',
      description: 'Achieved recognition for outstanding quality and customer satisfaction across all our technical service areas.',
      image: 'https://readdy.ai/api/search-image?query=Quality%20certificate%20and%20excellence%20award%2C%20professional%20recognition%2C%20achievement%20in%20technical%20services%2C%20customer%20satisfaction%2C%20quality%20assurance%20standards&width=400&height=300&seq=story4&orientation=landscape'
    },
    {
      year: '2022',
      title: 'Innovation Focus',
      description: 'Integrated latest technologies and innovative solutions to enhance service delivery and customer experience.',
      image: 'https://readdy.ai/api/search-image?query=Modern%20technology%20integration%2C%20innovative%20technical%20solutions%2C%20advanced%20tools%20and%20equipment%2C%20digital%20transformation%20in%20construction%20services%2C%20high-tech%20workspace&width=400&height=300&seq=story5&orientation=landscape'
    },
    {
      year: '2024',
      title: 'Market Leadership',
      description: 'Established as a leading technical services provider in Dubai, trusted by hundreds of satisfied clients.',
      image: 'https://readdy.ai/api/search-image?query=Business%20success%20and%20leadership%2C%20satisfied%20customers%2C%20professional%20achievement%2C%20market%20recognition%2C%20successful%20company%20growth%2C%20Dubai%20business%20excellence&width=400&height=300&seq=story6&orientation=landscape'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <section className="py-20 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h1 className="serif-title text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              Our Story
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From humble beginnings to becoming Dubai's trusted technical services provider, 
              our journey is built on expertise, dedication, and unwavering commitment to excellence.
            </p>
          </motion.div>

          <div className="relative">
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 bg-[#018589] h-full">
            
            </div>
            
            {timelineEvents.map((event, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className={`flex items-center mb-16 ${
                  index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'
                }`}
              >
                <div className="w-1/2 px-8">
                  <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                    <img
                      src={event.image}
                      alt={event.title}
                      className="w-full h-48 object-cover"
                    />
                    <div className="p-6">
                      <div className="text-[#018589] font-bold text-lg mb-2">
                        {event.year}
                      </div>
                      <h3 className="serif-title text-2xl font-semibold text-gray-900 mb-3">
                        {event.title}
                      </h3>
                      <p className="text-gray-600">
                        {event.description}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="absolute left-1/2 transform -translate-x-1/2 w-12 h-12 bg-[#018589] rounded-full flex items-center justify-center border-4 border-white shadow-lg">
                  <i className="ri-star-line text-white text-lg"></i>
                </div>
                
                <div className="w-1/2"></div>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mt-20 bg-gray-50 rounded-2xl p-12"
          >
            <h2 className="serif-title text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Our Mission
            </h2>
            <p className="text-lg text-gray-600 max-w-4xl mx-auto mb-8">
              To provide exceptional technical services that exceed client expectations through 
              innovative solutions, skilled craftsmanship, and unwavering commitment to quality. 
              We strive to be the most trusted technical services partner in Dubai and beyond.
            </p>
            <div className="grid md:grid-cols-3 gap-8 mt-12">
              {[
                {
                  icon: 'ri-eye-line',
                  title: 'Vision',
                  description: 'To be the leading technical services provider known for excellence and innovation'
                },
                {
                  icon: 'ri-heart-line',
                  title: 'Values',
                  description: 'Integrity, quality, customer satisfaction, and continuous improvement'
                },
                {
                  icon: 'ri-target-line',
                  title: 'Goal',
                  description: 'Delivering solutions that simplify complexity and exceed expectations'
                }
              ].map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="w-16 h-16 bg-[#018589] rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className={`${item.icon} text-white text-2xl`}></i>
                  </div>
                  <h3 className="serif-title text-xl font-semibold text-gray-900 mb-2">
                    {item.title}
                  </h3>
                  <p className="text-gray-600">
                    {item.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}