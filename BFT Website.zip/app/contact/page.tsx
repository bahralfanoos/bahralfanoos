'use client';

import { motion } from 'framer-motion';
import Header from '../../components/Header';
import Footer from '../../components/Footer';

export default function Contact() {
  const contactNumbers = [
    { number: '+971 55 950 8165', type: 'WhatsApp' }
  ];

  const handleCallClick = (number: string) => {
    window.open(`tel:${number}`, '_blank');
  };

  const handleWhatsAppClick = (number: string) => {
    const message = "Hi! I would like to inquire about your technical services.";
    window.open(`https://wa.me/${number.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(message)}`, '_blank');
  };

  const handleEmailClick = () => {
    window.open('mailto:info@bahralfanoos.com', '_blank');
  };

  const handleDirectionsClick = () => {
    window.open('https://maps.app.goo.gl/hnbmjuWk46q8Ufua8?g_st=aw', '_blank');
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <section className="py-20 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h1 className="serif-title text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              Visit Us
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Get in touch with our expert team for all your technical service needs. 
              We're here to help bring your projects to life.
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="bg-gray-50 rounded-2xl p-8 h-full">
                <h2 className="serif-title text-3xl font-bold text-gray-900 mb-8">
                  Contact Information
                </h2>

                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-[#018589] rounded-lg flex items-center justify-center flex-shrink-0">
                      <i className="ri-map-pin-line text-white text-xl"></i>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Our Location</h3>
                      <p className="text-gray-600 leading-relaxed">
                        Al Jamal Building 7, Shop # 01<br />
                        Nakheel Road, Near Pathan Masjid<br />
                        Naif Area, Deira<br />
                        Dubai, UAE
                      </p>
                      <button
                        onClick={handleDirectionsClick}
                        className="mt-3 text-[#018589] hover:text-[#016b6f] font-medium flex items-center"
                      >
                        Get Directions
                        <i className="ri-external-link-line ml-1"></i>
                      </button>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-[#018589] rounded-lg flex items-center justify-center flex-shrink-0">
                      <i className="ri-phone-line text-white text-xl"></i>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900 mb-4">Contact Numbers</h3>
                      <div className="space-y-3">
                        {contactNumbers.map((contact, index) => (
                          <div key={index} className="flex items-center justify-between bg-white rounded-lg p-3">
                            <div>
                              <span className="font-medium text-gray-900">{contact.number}</span>
                            </div>
                            <div className="flex space-x-2">
                              {contact.type === 'WhatsApp' && (
                                <button
                                  onClick={() => handleWhatsAppClick(contact.number)}
                                  className="w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center hover:bg-green-200 transition-colors"
                                >
                                  <i className="ri-whatsapp-line text-sm"></i>
                                </button>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-[#018589] rounded-lg flex items-center justify-center flex-shrink-0">
                      <i className="ri-mail-line text-white text-xl"></i>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900 mb-2">Email Address</h3>
                      <div className="bg-white rounded-lg p-3">
                        <div className="flex items-center justify-between">
                          <span className="font-medium text-gray-900">info@bahralfanoos.com</span>
                          <button
                            onClick={handleEmailClick}
                            className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center hover:bg-blue-200 transition-colors"
                          >
                            <i className="ri-mail-send-line text-sm"></i>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-[#018589] rounded-lg flex items-center justify-center flex-shrink-0">
                      <i className="ri-time-line text-white text-xl"></i>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Business Hours</h3>
                      <div className="text-gray-600 space-y-1">
                        <p>Saturday - Thursday: 8:00 AM - 8:00 PM</p>
                        <p>Friday: 2:00 PM - 8:00 PM</p>
                        <p className="text-sm text-[#018589] mt-2">
                          Emergency services available 24/7
                        </p>
                      </div>
                    </div>
                  </div>

                </div>

                <div className="mt-8 pt-8 border-t border-gray-200">
                  <h3 className="font-semibold text-gray-900 mb-4">Quick Actions</h3>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <a
                      href="https://wa.me/971559508165"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-[#018589] text-white px-6 py-3 rounded-lg hover:bg-[#016b6f] transition-colors flex items-center justify-center"
                    >
                      <i className="ri-whatsapp-line mr-2"></i>
                      WhatsApp Us
                    </a>
                    <button
                      onClick={handleEmailClick}
                      className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center"
                    >
                      <i className="ri-mail-line mr-2"></i>
                      Send Email
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <div className="bg-gray-50 rounded-2xl overflow-hidden h-full min-h-[600px]">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14433.146301496246!2d55.3139461!3d25.2724450!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f435184c58c0d%3A0x4cd42408b5f42b1e!2sBahr%20Al%20Fanoos%20Technical%20Services!5e0!3m2!1sen!2s!4v1703123456789!5m2!1sen!2s"
                  width="100%"
                  height="100%"
                  style={{ border: 0, minHeight: '600px' }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="BAHR AL FANOOS Location"
                ></iframe>
                
                <div className="absolute top-4 left-4 bg-white rounded-lg p-4 shadow-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-[#018589] rounded-lg flex items-center justify-center">
                      <i className="ri-building-line text-white"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">BAHR AL FANOOS</h4>
                      <p className="text-sm text-gray-600">Technical Services</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mt-16 bg-[#018589] rounded-2xl p-12 text-center text-white"
          >
            <h2 className="serif-title text-3xl md:text-4xl font-bold mb-6">
              Need Immediate Assistance?
            </h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto text-gray-100">
              Our team is ready to help with your technical service needs. 
              Contact us through WhatsApp, email, or call directly for quick responses and quotes.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="https://wa.me/971559508165"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center px-8 py-4 bg-white text-[#018589] font-semibold rounded-full hover:bg-gray-100 transition-all duration-300 transform hover:scale-105"
              >
                <i className="ri-whatsapp-line mr-2 text-lg"></i>
                Chat on WhatsApp
              </a>
              <button
                onClick={handleEmailClick}
                className="inline-flex items-center px-8 py-4 bg-transparent border-2 border-white text-white font-semibold rounded-full hover:bg-white hover:text-[#018589] transition-all duration-300 transform hover:scale-105"
              >
                <i className="ri-mail-line mr-2 text-lg"></i>
                Send Email
              </button>
              <button
                onClick={() => handleCallClick('+971559508165')}
                className="inline-flex items-center px-8 py-4 bg-transparent border-2 border-white text-white font-semibold rounded-full hover:bg-white hover:text-[#018589] transition-all duration-300 transform hover:scale-105"
              >
                <i className="ri-phone-line mr-2 text-lg"></i>
                Call Directly
              </button>
            </div>
          </motion.div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
}