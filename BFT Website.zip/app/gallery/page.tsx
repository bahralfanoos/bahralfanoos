
'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import Header from '../../components/Header';
import Footer from '../../components/Footer';

export default function Gallery() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState('All');

  const images = [
    {
      id: 1,
      src: 'https://readdy.ai/api/search-image?query=Professional%20aluminum%20window%20installation%20completed%20project%2C%20modern%20building%20exterior%20with%20aluminum%20frames%2C%20contemporary%20architecture%2C%20high-quality%20aluminum%20work&width=400&height=600&seq=gallery1&orientation=portrait',
      category: 'Aluminum',
      title: 'Modern Aluminum Windows'
    },
    {
      id: 101,
      src: 'https://readdy.ai/api/search-image?query=Aluminum%20curtain%20wall%20system%20installation%2C%20modern%20glass%20facade%20with%20aluminum%20framework%2C%20contemporary%20commercial%20building%20exterior%2C%20professional%20aluminum%20curtain%20wall&width=600&height=800&seq=gallery101&orientation=portrait',
      category: 'Aluminum',
      title: 'Aluminum Curtain Wall'
    },
    {
      id: 102,
      src: 'https://readdy.ai/api/search-image?query=Aluminum%20sliding%20door%20installation%2C%20modern%20patio%20door%20system%2C%20contemporary%20aluminum%20door%20frames%2C%20sleek%20sliding%20glass%20doors%20with%20aluminum%20tracks&width=500&height=400&seq=gallery102&orientation=landscape',
      category: 'Aluminum',
      title: 'Aluminum Sliding Doors'
    },
    {
      id: 103,
      src: 'https://readdy.ai/api/search-image?query=Aluminum%20shopfront%20installation%2C%20modern%20commercial%20storefront%2C%20contemporary%20retail%20facade%2C%20professional%20aluminum%20and%20glass%20shopfront%20system&width=600&height=400&seq=gallery103&orientation=landscape',
      category: 'Aluminum',
      title: 'Aluminum Shopfront'
    },
    {
      id: 104,
      src: 'https://readdy.ai/api/search-image?query=Aluminum%20balcony%20railing%20installation%2C%20modern%20safety%20railings%2C%20contemporary%20balcony%20barriers%2C%20sleek%20aluminum%20railing%20system%20with%20glass%20panels&width=400&height=300&seq=gallery104&orientation=landscape',
      category: 'Aluminum',
      title: 'Aluminum Railings'
    },
    {
      id: 105,
      src: 'https://readdy.ai/api/search-image?query=Aluminum%20cladding%20panel%20installation%2C%20modern%20building%20facade%2C%20contemporary%20aluminum%20exterior%20cladding%2C%20professional%20metal%20panel%20system&width=400&height=600&seq=gallery105&orientation=portrait',
      category: 'Aluminum',
      title: 'Aluminum Cladding Panels'
    },
    {
      id: 2,
      src: 'https://readdy.ai/api/search-image?query=Elegant%20tempered%20glass%20door%20installation%2C%20modern%20glass%20entrance%2C%20contemporary%20building%20entry%2C%20professional%20glass%20door%20fitting&width=400&height=300&seq=gallery2&orientation=landscape',
      category: 'Glass',
      title: 'Tempered Glass Doors'
    },
    {
      id: 3,
      src: 'https://readdy.ai/api/search-image?query=Modern%20office%20glass%20partition%20completed%20installation%2C%20transparent%20workspace%20dividers%2C%20contemporary%20office%20interior%20design&width=600&height=400&seq=gallery3&orientation=landscape',
      category: 'Glass',
      title: 'Office Glass Partitions'
    },
    {
      id: 106,
      src: 'https://readdy.ai/api/search-image?query=Laminated%20glass%20installation%20project%2C%20safety%20glass%20panels%2C%20modern%20security%20glazing%2C%20contemporary%20building%20safety%20glass%20with%20clear%20visibility&width=400&height=600&seq=gallery106&orientation=portrait',
      category: 'Glass',
      title: 'Laminated Safety Glass'
    },
    {
      id: 107,
      src: 'https://readdy.ai/api/search-image?query=Double%20glazed%20window%20installation%2C%20energy%20efficient%20glazing%2C%20modern%20insulated%20glass%20units%2C%20contemporary%20thermal%20glass%20windows&width=500&height=400&seq=gallery107&orientation=landscape',
      category: 'Glass',
      title: 'Double Glazed Windows'
    },
    {
      id: 108,
      src: 'https://readdy.ai/api/search-image?query=Glass%20curtain%20wall%20installation%2C%20modern%20building%20facade%20glazing%2C%20contemporary%20all-glass%20exterior%2C%20professional%20structural%20glazing%20system&width=600&height=800&seq=gallery108&orientation=portrait',
      category: 'Glass',
      title: 'Glass Curtain Wall'
    },
    {
      id: 109,
      src: 'https://readdy.ai/api/search-image?query=Decorative%20glass%20panel%20installation%2C%20artistic%20glass%20work%2C%20contemporary%20colored%20glass%20panels%2C%20modern%20decorative%20glazing%20with%20patterns&width=400&height=300&seq=gallery109&orientation=landscape',
      category: 'Glass',
      title: 'Decorative Glass Panels'
    },
    {
      id: 110,
      src: 'https://readdy.ai/api/search-image?query=Glass%20balustrade%20installation%2C%20modern%20glass%20railing%20system%2C%20contemporary%20safety%20barriers%2C%20sleek%20frameless%20glass%20balustrade&width=600&height=400&seq=gallery110&orientation=landscape',
      category: 'Glass',
      title: 'Glass Balustrade'
    },
    {
      id: 4,
      src: 'https://readdy.ai/api/search-image?query=Professional%20air%20conditioning%20installation%20completed%2C%20modern%20AC%20units%2C%20cooling%20system%20installation%2C%20HVAC%20project%20completion&width=400&height=300&seq=gallery4&orientation=landscape',
      category: 'HVAC',
      title: 'AC Installation Project'
    },
    {
      id: 12,
      src: 'https://readdy.ai/api/search-image?query=Professional%20ventilation%20system%20installation%20completed%2C%20air%20duct%20work%2C%20HVAC%20ventilation%20project%2C%20industrial%20ventilation%20setup&width=600&height=400&seq=gallery12&orientation=landscape',
      category: 'HVAC',
      title: 'Ventilation System'
    },
    {
      id: 111,
      src: 'https://readdy.ai/api/search-image?query=Central%20air%20conditioning%20system%20installation%2C%20large%20commercial%20HVAC%20units%2C%20modern%20cooling%20system%2C%20professional%20central%20AC%20installation&width=600&height=400&seq=gallery111&orientation=landscape',
      category: 'HVAC',
      title: 'Central Air System'
    },
    {
      id: 112,
      src: 'https://readdy.ai/api/search-image?query=Ductwork%20installation%20project%2C%20modern%20air%20distribution%20system%2C%20HVAC%20duct%20network%2C%20professional%20ventilation%20ductwork&width=400&height=300&seq=gallery112&orientation=landscape',
      category: 'HVAC',
      title: 'Ductwork Installation'
    },
    {
      id: 113,
      src: 'https://readdy.ai/api/search-image?query=Split%20air%20conditioning%20installation%2C%20modern%20split%20AC%20units%2C%20wall%20mounted%20cooling%20system%2C%20contemporary%20split%20system%20installation&width=400&height=600&seq=gallery113&orientation=portrait',
      category: 'HVAC',
      title: 'Split AC System'
    },
    {
      id: 114,
      src: 'https://readdy.ai/api/search-image?query=Chiller%20system%20installation%2C%20large%20scale%20cooling%20equipment%2C%20commercial%20chiller%20unit%2C%20industrial%20HVAC%20chiller%20installation&width=600&height=400&seq=gallery114&orientation=landscape',
      category: 'HVAC',
      title: 'Chiller System'
    },
    {
      id: 115,
      src: 'https://readdy.ai/api/search-image?query=Exhaust%20fan%20installation%20project%2C%20industrial%20ventilation%20fans%2C%20modern%20exhaust%20system%2C%20professional%20fan%20installation%20work&width=400&height=300&seq=gallery115&orientation=landscape',
      category: 'HVAC',
      title: 'Exhaust Fan System'
    },
    {
      id: 5,
      src: 'https://readdy.ai/api/search-image?query=Beautiful%20bathroom%20mirror%20installation%2C%20modern%20bathroom%20interior%2C%20elegant%20mirror%20mounting%2C%20professional%20mirror%20fitting&width=300&height=400&seq=gallery5&orientation=portrait',
      category: 'Installation',
      title: 'Bathroom Mirror Installation'
    },
    {
      id: 116,
      src: 'https://readdy.ai/api/search-image?query=Ceiling%20fan%20installation%20project%2C%20modern%20ceiling%20fans%2C%20contemporary%20fan%20mounting%2C%20professional%20electrical%20installation%20work&width=400&height=300&seq=gallery116&orientation=landscape',
      category: 'Installation',
      title: 'Ceiling Fan Installation'
    },
    {
      id: 117,
      src: 'https://readdy.ai/api/search-image?query=Kitchen%20hood%20installation%2C%20modern%20range%20hood%20mounting%2C%20contemporary%20kitchen%20ventilation%2C%20professional%20hood%20installation%20work&width=600&height=400&seq=gallery117&orientation=landscape',
      category: 'Installation',
      title: 'Kitchen Hood Installation'
    },
    {
      id: 118,
      src: 'https://readdy.ai/api/search-image?query=Light%20fixture%20installation%20project%2C%20modern%20lighting%20setup%2C%20contemporary%20ceiling%20lights%2C%20professional%20electrical%20fixture%20mounting&width=400&height=600&seq=gallery118&orientation=portrait',
      category: 'Installation',
      title: 'Light Fixture Installation'
    },
    {
      id: 119,
      src: 'https://readdy.ai/api/search-image?query=Water%20heater%20installation%2C%20modern%20boiler%20setup%2C%20contemporary%20water%20heating%20system%2C%20professional%20plumbing%20installation&width=400&height=300&seq=gallery119&orientation=landscape',
      category: 'Installation',
      title: 'Water Heater Installation'
    },
    {
      id: 120,
      src: 'https://readdy.ai/api/search-image?query=TV%20wall%20mounting%20installation%2C%20modern%20television%20mounting%2C%20contemporary%20media%20wall%20setup%2C%20professional%20TV%20installation%20service&width=600&height=400&seq=gallery120&orientation=landscape',
      category: 'Installation',
      title: 'TV Wall Mounting'
    },
    {
      id: 7,
      src: 'https://readdy.ai/api/search-image?query=Professional%20floor%20tiling%20installation%20completed%2C%20modern%20ceramic%20tile%20flooring%2C%20beautiful%20tile%20pattern%2C%20quality%20flooring%20work&width=600&height=400&seq=gallery7&orientation=landscape',
      category: 'Flooring',
      title: 'Ceramic Floor Tiling'
    },
    {
      id: 121,
      src: 'https://readdy.ai/api/search-image?query=Marble%20flooring%20installation%20project%2C%20luxury%20marble%20floor%20laying%2C%20elegant%20stone%20flooring%2C%20professional%20marble%20installation%20work&width=600&height=400&seq=gallery121&orientation=landscape',
      category: 'Flooring',
      title: 'Marble Flooring'
    },
    {
      id: 122,
      src: 'https://readdy.ai/api/search-image?query=Hardwood%20floor%20installation%2C%20natural%20wood%20flooring%20project%2C%20contemporary%20timber%20floor%20laying%2C%20professional%20wood%20floor%20installation&width=400&height=300&seq=gallery122&orientation=landscape',
      category: 'Flooring',
      title: 'Hardwood Floor Installation'
    },
    {
      id: 123,
      src: 'https://readdy.ai/api/search-image?query=Vinyl%20flooring%20installation%20project%2C%20modern%20PVC%20floor%20laying%2C%20contemporary%20vinyl%20planks%2C%20waterproof%20flooring%20installation&width=400&height=600&seq=gallery123&orientation=portrait',
      category: 'Flooring',
      title: 'Vinyl Flooring'
    },
    {
      id: 124,
      src: 'https://readdy.ai/api/search-image?query=Laminate%20flooring%20installation%2C%20modern%20laminate%20planks%2C%20contemporary%20floor%20covering%2C%20durable%20flooring%20solution%20installation&width=600&height=400&seq=gallery124&orientation=landscape',
      category: 'Flooring',
      title: 'Laminate Flooring'
    },
    {
      id: 125,
      src: 'https://readdy.ai/api/search-image?query=Epoxy%20floor%20coating%20installation%2C%20industrial%20floor%20treatment%2C%20modern%20epoxy%20flooring%2C%20contemporary%20seamless%20floor%20coating&width=400&height=300&seq=gallery125&orientation=landscape',
      category: 'Flooring',
      title: 'Epoxy Floor Coating'
    },
    {
      id: 8,
      src: 'https://readdy.ai/api/search-image?query=Modern%20building%20cladding%20installation%20completed%2C%20exterior%20wall%20cladding%2C%20contemporary%20building%20facade%2C%20professional%20cladding%20work&width=400&height=600&seq=gallery8&orientation=portrait',
      category: 'Cladding',
      title: 'Building Cladding'
    },
    {
      id: 126,
      src: 'https://readdy.ai/api/search-image?query=Stone%20cladding%20installation%20project%2C%20natural%20stone%20facade%2C%20contemporary%20stone%20wall%20cladding%2C%20professional%20stone%20veneer%20work&width=400&height=600&seq=gallery126&orientation=portrait',
      category: 'Cladding',
      title: 'Stone Cladding'
    },
    {
      id: 127,
      src: 'https://readdy.ai/api/search-image?query=Metal%20cladding%20panel%20installation%2C%20modern%20metal%20facade%2C%20contemporary%20steel%20cladding%2C%20professional%20metal%20panel%20system&width=600&height=400&seq=gallery127&orientation=landscape',
      category: 'Cladding',
      title: 'Metal Cladding'
    },
    {
      id: 128,
      src: 'https://readdy.ai/api/search-image?query=Composite%20cladding%20installation%2C%20modern%20composite%20panels%2C%20contemporary%20fiber%20cement%20cladding%2C%20durable%20exterior%20cladding%20system&width=400&height=300&seq=gallery128&orientation=landscape',
      category: 'Cladding',
      title: 'Composite Cladding'
    },
    {
      id: 129,
      src: 'https://readdy.ai/api/search-image?query=Wood%20cladding%20installation%20project%2C%20natural%20timber%20facade%2C%20contemporary%20wood%20siding%2C%20modern%20wooden%20exterior%20cladding&width=400&height=600&seq=gallery129&orientation=portrait',
      category: 'Cladding',
      title: 'Wood Cladding'
    },
    {
      id: 130,
      src: 'https://readdy.ai/api/search-image?query=Brick%20cladding%20installation%2C%20modern%20brick%20facade%2C%20contemporary%20masonry%20cladding%2C%20professional%20brick%20veneer%20work&width=600&height=400&seq=gallery130&orientation=landscape',
      category: 'Cladding',
      title: 'Brick Cladding'
    },
    {
      id: 9,
      src: 'https://readdy.ai/api/search-image?query=Professional%20interior%20painting%20completed%2C%20beautifully%20painted%20walls%2C%20modern%20interior%20paint%20finish%2C%20quality%20painting%20work&width=400&height=300&seq=gallery9&orientation=landscape',
      category: 'Painting',
      title: 'Interior Painting'
    },
    {
      id: 131,
      src: 'https://readdy.ai/api/search-image?query=Exterior%20building%20painting%20project%2C%20modern%20facade%20painting%2C%20contemporary%20building%20paint%20job%2C%20professional%20exterior%20painting%20work&width=400&height=600&seq=gallery131&orientation=portrait',
      category: 'Painting',
      title: 'Exterior Building Painting'
    },
    {
      id: 132,
      src: 'https://readdy.ai/api/search-image?query=Textured%20wall%20painting%2C%20decorative%20paint%20finish%2C%20contemporary%20wall%20texture%2C%20artistic%20painting%20techniques%2C%20modern%20textured%20coating&width=600&height=400&seq=gallery132&orientation=landscape',
      category: 'Painting',
      title: 'Textured Wall Painting'
    },
    {
      id: 133,
      src: 'https://readdy.ai/api/search-image?query=Ceiling%20painting%20project%2C%20modern%20ceiling%20paint%20job%2C%20contemporary%20ceiling%20finish%2C%20professional%20overhead%20painting%20work&width=400&height=300&seq=gallery133&orientation=landscape',
      category: 'Painting',
      title: 'Ceiling Painting'
    },
    {
      id: 134,
      src: 'https://readdy.ai/api/search-image?query=Metal%20structure%20painting%2C%20industrial%20painting%20work%2C%20modern%20steel%20painting%2C%20contemporary%20metal%20coating%2C%20protective%20paint%20system&width=400&height=600&seq=gallery134&orientation=portrait',
      category: 'Painting',
      title: 'Metal Structure Painting'
    },
    {
      id: 135,
      src: 'https://readdy.ai/api/search-image?query=Wood%20staining%20and%20painting%2C%20modern%20wood%20finish%2C%20contemporary%20timber%20painting%2C%20professional%20wood%20coating%20work&width=600&height=400&seq=gallery135&orientation=landscape',
      category: 'Painting',
      title: 'Wood Painting & Staining'
    },
    {
      id: 10,
      src: 'https://readdy.ai/api/search-image?query=Modern%20plumbing%20installation%20completed%2C%20bathroom%20plumbing%20work%2C%20professional%20pipe%20installation%2C%20quality%20plumbing%20project&width=300&height=400&seq=gallery10&orientation=portrait',
      category: 'Plumbing',
      title: 'Plumbing Installation'
    },
    {
      id: 136,
      src: 'https://readdy.ai/api/search-image?query=Kitchen%20plumbing%20installation%2C%20modern%20kitchen%20pipes%2C%20contemporary%20sink%20plumbing%2C%20professional%20kitchen%20water%20system&width=600&height=400&seq=gallery136&orientation=landscape',
      category: 'Plumbing',
      title: 'Kitchen Plumbing'
    },
    {
      id: 137,
      src: 'https://readdy.ai/api/search-image?query=Water%20supply%20system%20installation%2C%20modern%20water%20pipes%2C%20contemporary%20plumbing%20network%2C%20professional%20water%20distribution%20system&width=400&height=300&seq=gallery137&orientation=landscape',
      category: 'Plumbing',
      title: 'Water Supply System'
    },
    {
      id: 138,
      src: 'https://readdy.ai/api/search-image?query=Drainage%20system%20installation%2C%20modern%20sewage%20pipes%2C%20contemporary%20drain%20network%2C%20professional%20wastewater%20system&width=400&height=600&seq=gallery138&orientation=portrait',
      category: 'Plumbing',
      title: 'Drainage System'
    },
    {
      id: 139,
      src: 'https://readdy.ai/api/search-image?query=Shower%20plumbing%20installation%2C%20modern%20bathroom%20fixtures%2C%20contemporary%20shower%20system%2C%20professional%20bathroom%20plumbing%20work&width=600&height=400&seq=gallery139&orientation=landscape',
      category: 'Plumbing',
      title: 'Shower Plumbing'
    },
    {
      id: 140,
      src: 'https://readdy.ai/api/search-image?query=Water%20heater%20plumbing%20connection%2C%20modern%20boiler%20installation%2C%20contemporary%20heating%20system%2C%20professional%20water%20heating%20setup&width=400&height=300&seq=gallery140&orientation=landscape',
      category: 'Plumbing',
      title: 'Water Heater Plumbing'
    },
    {
      id: 11,
      src: 'https://readdy.ai/api/search-image?query=Luxury%20bathroom%20sanitary%20installation%20completed%2C%20modern%20bathroom%20fixtures%2C%20elegant%20toilet%20and%20basin%20fitting%2C%20professional%20sanitary%20work&width=400&height=300&seq=gallery11&orientation=landscape',
      category: 'Sanitary',
      title: 'Sanitary Installation'
    },
    {
      id: 141,
      src: 'https://readdy.ai/api/search-image?query=Modern%20toilet%20installation%2C%20contemporary%20WC%20fitting%2C%20luxury%20bathroom%20toilet%2C%20professional%20sanitary%20fixture%20installation&width=400&height=600&seq=gallery141&orientation=portrait',
      category: 'Sanitary',
      title: 'Modern Toilet Installation'
    },
    {
      id: 142,
      src: 'https://readdy.ai/api/search-image?query=Washbasin%20installation%20project%2C%20modern%20bathroom%20sink%2C%20contemporary%20basin%20fitting%2C%20elegant%20sanitary%20basin%20installation&width=600&height=400&seq=gallery142&orientation=landscape',
      category: 'Sanitary',
      title: 'Washbasin Installation'
    },
    {
      id: 143,
      src: 'https://readdy.ai/api/search-image?query=Bathtub%20installation%20project%2C%20modern%20bath%20fitting%2C%20contemporary%20bathroom%20tub%2C%20luxury%20bathtub%20installation%20work&width=400&height=300&seq=gallery143&orientation=landscape',
      category: 'Sanitary',
      title: 'Bathtub Installation'
    },
    {
      id: 144,
      src: 'https://readdy.ai/api/search-image?query=Shower%20cubicle%20installation%2C%20modern%20shower%20enclosure%2C%20contemporary%20shower%20cabin%2C%20professional%20shower%20unit%20fitting&width=400&height=600&seq=gallery144&orientation=portrait',
      category: 'Sanitary',
      title: 'Shower Cubicle'
    },
    {
      id: 145,
      src: 'https://readdy.ai/api/search-image?query=Kitchen%20sink%20installation%2C%20modern%20kitchen%20basin%2C%20contemporary%20sink%20fitting%2C%20professional%20kitchen%20sanitary%20work&width=600&height=400&seq=gallery145&orientation=landscape',
      category: 'Sanitary',
      title: 'Kitchen Sink Installation'
    },
    {
      id: 146,
      src: 'https://readdy.ai/api/search-image?query=Professional%20drywall%20installation%20project%2C%20modern%20gypsum%20board%20mounting%2C%20contemporary%20wall%20framing%2C%20expert%20drywall%20construction%20work&width=600&height=400&seq=gallery146&orientation=landscape',
      category: 'Drywall',
      title: 'Drywall Installation'
    },
    {
      id: 147,
      src: 'https://readdy.ai/api/search-image?query=Drywall%20taping%20and%20mudding%20work%2C%20professional%20joint%20finishing%2C%20smooth%20wall%20texture%2C%20expert%20drywall%20seam%20treatment&width=400&height=600&seq=gallery147&orientation=portrait',
      category: 'Drywall',
      title: 'Drywall Taping & Finishing'
    },
    {
      id: 148,
      src: 'https://readdy.ai/api/search-image?query=Ceiling%20drywall%20installation%2C%20modern%20suspended%20ceiling%20construction%2C%20contemporary%20overhead%20drywall%20work%2C%20professional%20ceiling%20finishing&width=600&height=400&seq=gallery148&orientation=landscape',
      category: 'Drywall',
      title: 'Ceiling Drywall'
    },
    {
      id: 149,
      src: 'https://readdy.ai/api/search-image?query=Drywall%20partition%20construction%2C%20modern%20room%20divider%20installation%2C%20contemporary%20wall%20partition%20work%2C%20professional%20interior%20wall%20building&width=400&height=300&seq=gallery149&orientation=landscape',
      category: 'Drywall',
      title: 'Drywall Partitions'
    },
    {
      id: 150,
      src: 'https://readdy.ai/api/search-image?query=Drywall%20repair%20and%20patching%20work%2C%20professional%20wall%20hole%20repair%2C%20contemporary%20drywall%20maintenance%2C%20expert%20wall%20restoration%20service&width=400&height=600&seq=gallery150&orientation=portrait',
      category: 'Drywall',
      title: 'Drywall Repair'
    },
    {
      id: 151,
      src: 'https://readdy.ai/api/search-image?query=Textured%20drywall%20finishing%2C%20modern%20wall%20texture%20application%2C%20contemporary%20decorative%20drywall%2C%20professional%20texture%20coating%20work&width=600&height=400&seq=gallery151&orientation=landscape',
      category: 'Drywall',
      title: 'Textured Drywall'
    },
    {
      id: 152,
      src: 'https://readdy.ai/api/search-image?query=Fire-rated%20drywall%20installation%2C%20modern%20fireproof%20wall%20construction%2C%20contemporary%20fire-resistant%20drywall%2C%20professional%20safety%20wall%20system&width=400&height=300&seq=gallery152&orientation=landscape',
      category: 'Drywall',
      title: 'Fire-Rated Drywall'
    },
    {
      id: 153,
      src: 'https://readdy.ai/api/search-image?query=Moisture-resistant%20drywall%20installation%2C%20bathroom%20greenboard%20installation%2C%20contemporary%20wet%20area%20drywall%2C%20professional%20moisture-proof%20wall%20construction&width=400&height=600&seq=gallery153&orientation=portrait',
      category: 'Drywall',
      title: 'Moisture-Resistant Drywall'
    },
    {
      id: 154,
      src: 'https://readdy.ai/api/search-image?query=Curved%20drywall%20installation%2C%20modern%20curved%20wall%20construction%2C%20contemporary%20architectural%20drywall%2C%20professional%20curved%20partition%20work&width=600&height=400&seq=gallery154&orientation=portrait',
      category: 'Drywall',
      title: 'Curved Drywall'
    },
    {
      id: 6,
      src: 'https://static.readdy.ai/image/e8dfff83411bbf36d8e6bb6305365a1e/c4ce2e71ef365f854e5308a037f02b79.jfif',
      category: 'Carpentry',
      title: 'Custom Woodwork'
    },
    {
      id: 13,
      src: 'https://readdy.ai/api/search-image?query=Professional%20kitchen%20cabinet%20installation%20completed%20project%2C%20custom%20wooden%20cabinets%2C%20modern%20kitchen%20carpentry%20work%2C%20quality%20wood%20finishing%2C%20expert%20cabinet%20making%20craftsmanship&width=600&height=400&seq=gallery13&orientation=landscape',
      category: 'Carpentry',
      title: 'Kitchen Cabinet Installation'
    },
    {
      id: 14,
      src: 'https://readdy.ai/api/search-image?query=Custom%20wooden%20wardrobe%20construction%2C%20built-in%20closet%20carpentry%2C%20bedroom%20furniture%20installation%2C%20professional%20wood%20craftsmanship%2C%20modern%20wardrobe%20design&width=400&height=600&seq=gallery14&orientation=portrait',
      category: 'Carpentry',
      title: 'Built-in Wardrobe'
    },
    {
      id: 15,
      src: 'https://readdy.ai/api/search-image?query=Wooden%20flooring%20installation%20project%2C%20hardwood%20floor%20carpentry%2C%20professional%20wood%20floor%20laying%2C%20quality%20timber%20flooring%20work%2C%20expert%20floor%20installation&width=600&height=400&seq=gallery15&orientation=landscape',
      category: 'Carpentry',
      title: 'Wooden Flooring'
    },
    {
      id: 16,
      src: 'https://readdy.ai/api/search-image?query=Custom%20wooden%20shelving%20unit%20construction%2C%20built-in%20bookshelf%20carpentry%2C%20library%20shelving%20installation%2C%20professional%20woodwork%20storage%20solutions&width=400&height=500&seq=gallery16&orientation=portrait',
      category: 'Carpentry',
      title: 'Custom Shelving Unit'
    },
    {
      id: 17,
      src: 'https://readdy.ai/api/search-image?query=Wooden%20door%20frame%20installation%2C%20custom%20door%20carpentry%20work%2C%20professional%20door%20fitting%2C%20quality%20wood%20door%20construction%2C%20expert%20door%20installation&width=400&height=600&seq=gallery17&orientation=portrait',
      category: 'Carpentry',
      title: 'Wooden Door Installation'
    },
    {
      id: 18,
      src: 'https://readdy.ai/api/search-image?query=Office%20desk%20carpentry%20project%2C%20custom%20wooden%20furniture%20making%2C%20professional%20office%20furniture%20construction%2C%20quality%20wood%20office%20desk%20installation&width=600&height=400&seq=gallery18&orientation=landscape',
      category: 'Carpentry',
      title: 'Custom Office Desk'
    }
  ];

  const categories = ['All', 'Carpentry', 'Aluminum', 'Glass', 'HVAC', 'Installation', 'Flooring', 'Cladding', 'Painting', 'Plumbing', 'Sanitary', 'Drywall'];

  const filteredImages = activeFilter === 'All' ? images : images.filter(image => image.category === activeFilter);

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <section className="py-20 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <h1 className="serif-title text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              Our Gallery
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Explore our portfolio of completed projects showcasing our expertise and commitment to quality across all technical services.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex flex-wrap justify-center gap-4 mb-12"
          >
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveFilter(category)}
                className={`px-6 py-3 rounded-full font-medium transition-all duration-300 ${activeFilter === category ? 'bg-[#018589] text-white shadow-lg' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
              >
                {category}
              </button>
            ))}
          </motion.div>

          <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
            {filteredImages.map((image, index) => (
              <motion.div
                key={image.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="break-inside-avoid bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer"
                onClick={() => setSelectedImage(image.src)}
              >
                <div className="relative overflow-hidden group">
                  <img
                    src={image.src}
                    alt={image.title}
                    className="w-full h-auto object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300 flex items-center justify-center">
                    <i className="ri-zoom-in-line text-white text-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></i>
                  </div>
                  <div className="absolute top-4 left-4">
                    <span className="bg-[#018589] text-white px-3 py-1 rounded-full text-sm font-medium">
                      {image.category}
                    </span>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="serif-title text-lg font-semibold text-gray-900">
                    {image.title}
                  </h3>
                </div>
              </motion.div>
            ))}
          </div>

          {selectedImage && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="fixed inset-0 z-50 bg-black bg-opacity-90 flex items-center justify-center p-4"
              onClick={() => setSelectedImage(null)}
            >
              <motion.div
                initial={{ scale: 0.5 }}
                animate={{ scale: 1 }}
                className="relative max-w-4xl max-h-full"
              >
                <img
                  src={selectedImage}
                  alt="Gallery Image"
                  className="max-w-full max-h-full object-contain rounded-lg"
                />
                <button
                  onClick={() => setSelectedImage(null)}
                  className="absolute top-4 right-4 w-10 h-10 bg-white rounded-full flex items-center justify-center hover:bg-gray-100 transition-colors"
                >
                  <i className="ri-close-line text-xl text-gray-700"></i>
                </button>
              </motion.div>
            </motion.div>
          )}

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mt-16 bg-gray-50 rounded-2xl p-12"
          >
            <h2 className="serif-title text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Ready to Start Your Project?
            </h2>
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              Inspired by our work? Let's discuss how we can bring your vision to life with our expert technical services.
            </p>
            <a
              href="https://wa.me/971559508165"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-8 py-4 bg-[#018589] text-white font-semibold rounded-full hover:bg-[#016b6f] transition-all duration-300 transform hover:scale-105"
            >
              Get Quote on WhatsApp
              <i className="ri-whatsapp-line ml-2 text-lg"></i>
            </a>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
