'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import Header from '../../components/Header';
import Footer from '../../components/Footer';

export default function Services() {
  const [activeFilter, setActiveFilter] = useState('All');

  const services = [
    {
      id: 11,
      name: 'Carpentry',
      category: 'Construction',
      description: 'Custom carpentry and woodwork solutions',
      image: 'https://readdy.ai/api/search-image?query=Professional%20carpentry%20work%2C%20custom%20wood%20furniture%2C%20skilled%20carpenter%20with%20tools%2C%20wooden%20cabinet%20installation%2C%20quality%20woodwork%20craftsmanship&width=400&height=300&seq=service11&orientation=landscape',
      price: 'Contact for Quote'
    },
    {
      id: 14,
      name: 'Drywall',
      category: 'Construction',
      description: 'Professional drywall installation, finishing and repair services',
      image: 'https://readdy.ai/api/search-image?query=Professional%20drywall%20installation%2C%20gypsum%20board%20mounting%2C%20wall%20construction%20work%2C%20interior%20drywall%20finishing%2C%20construction%20worker%20installing%20drywall%20panels&width=400&height=300&seq=service14&orientation=landscape',
      price: 'Contact for Quote'
    },
    {
      id: 1,
      name: 'Aluminium Work',
      category: 'Construction',
      description: 'Professional aluminum fabrication and installation services',
      image: 'https://readdy.ai/api/search-image?query=Professional%20aluminum%20window%20and%20door%20installation%2C%20modern%20aluminum%20fabrication%20work%2C%20sleek%20metallic%20finishes%2C%20contemporary%20building%20elements%2C%20high-quality%20aluminum%20construction&width=400&height=300&seq=service1&orientation=landscape',
      price: 'Contact for Quote'
    },
    {
      id: 2,
      name: 'Tempered Door',
      category: 'Glass',
      description: 'High-quality tempered glass door installation and repair',
      image: 'https://readdy.ai/api/search-image?query=Modern%20tempered%20glass%20door%20installation%2C%20transparent%20glass%20entrance%2C%20professional%20door%20fitting%2C%20contemporary%20glass%20architecture%2C%20sleek%20door%20design&width=400&height=300&seq=service2&orientation=landscape',
      price: 'Contact for Quote'
    },
    {
      id: 3,
      name: 'Partition Glass',
      category: 'Glass',
      description: 'Modern glass partition solutions for offices and homes',
      image: 'https://readdy.ai/api/search-image?query=Modern%20office%20glass%20partition%20installation%2C%20transparent%20room%20dividers%2C%20contemporary%20workspace%20design%2C%20professional%20glass%20partitioning%2C%20sleek%20office%20interior&width=400&height=300&seq=service3&orientation=landscape',
      price: 'Contact for Quote'
    },
    {
      id: 4,
      name: 'Mirror Fixing',
      category: 'Installation',
      description: 'Expert mirror installation and mounting services',
      image: 'https://readdy.ai/api/search-image?query=Professional%20mirror%20installation%20and%20mounting%2C%20bathroom%20mirror%20fitting%2C%20decorative%20mirror%20placement%2C%20expert%20mirror%20fixing%20service%2C%20residential%20mirror%20installation&width=400&height=300&seq=service4&orientation=landscape',
      price: 'Contact for Quote'
    },
    {
      id: 5,
      name: 'Air-Conditioning',
      category: 'HVAC',
      description: 'Complete AC installation, maintenance and repair services',
      image: 'https://readdy.ai/api/search-image?query=Professional%20air%20conditioning%20installation%2C%20AC%20unit%20maintenance%2C%20cooling%20system%20repair%2C%20HVAC%20technician%20at%20work%2C%20modern%20air%20conditioning%20service&width=400&height=300&seq=service5&orientation=landscape',
      price: 'Contact for Quote'
    },
    {
      id: 6,
      name: 'Ventilation',
      category: 'HVAC',
      description: 'Professional ventilation system installation and maintenance',
      image: 'https://readdy.ai/api/search-image?query=Ventilation%20system%20installation%2C%20air%20duct%20work%2C%20professional%20HVAC%20ventilation%2C%20industrial%20ventilation%20setup%2C%20air%20circulation%20system%20maintenance&width=400&height=300&seq=service6&orientation=landscape',
      price: 'Contact for Quote'
    },
    {
      id: 7,
      name: 'Maintenance',
      category: 'General',
      description: 'Comprehensive building and facility maintenance services',
      image: 'https://readdy.ai/api/search-image?query=Professional%20building%20maintenance%20service%2C%20facility%20maintenance%20work%2C%20general%20repair%20and%20upkeep%2C%20maintenance%20technician%2C%20building%20care%20services&width=400&height=300&seq=service7&orientation=landscape',
      price: 'Contact for Quote'
    },
    {
      id: 8,
      name: 'Plumbing',
      category: 'Installation',
      description: 'Expert plumbing installation, repair and maintenance',
      image: 'https://readdy.ai/api/search-image?query=Professional%20plumbing%20installation%2C%20pipe%20fitting%20work%2C%20bathroom%20plumbing%20repair%2C%20expert%20plumber%20at%20work%2C%20modern%20plumbing%20solutions&width=400&height=300&seq=service8&orientation=landscape',
      price: 'Contact for Quote'
    },
    {
      id: 9,
      name: 'Sanitary',
      category: 'Installation',
      description: 'Sanitary ware installation and bathroom fitting services',
      image: 'https://readdy.ai/api/search-image?query=Modern%20bathroom%20sanitary%20installation%2C%20toilet%20and%20basin%20fitting%2C%20contemporary%20bathroom%20fixtures%2C%20professional%20sanitary%20ware%20installation%2C%20luxury%20bathroom%20setup&width=400&height=300&seq=service9&orientation=landscape',
      price: 'Contact for Quote'
    },
    {
      id: 10,
      name: 'Painting',
      category: 'Finishing',
      description: 'Professional interior and exterior painting services',
      image: 'https://readdy.ai/api/search-image?query=Professional%20wall%20painting%20service%2C%20interior%20painting%20work%2C%20exterior%20building%20painting%2C%20painter%20with%20brushes%20and%20colors%2C%20high-quality%20paint%20finishing&width=400&height=300&seq=service10&orientation=landscape',
      price: 'Contact for Quote'
    },
    {
      id: 12,
      name: 'Flooring Tiles',
      category: 'Finishing',
      description: 'Professional tile installation and flooring services',
      image: 'https://readdy.ai/api/search-image?query=Professional%20tile%20flooring%20installation%2C%20ceramic%20and%20marble%20tile%20laying%2C%20floor%20tiling%20work%2C%20expert%20tile%20fitter%2C%20modern%20flooring%20solutions&width=400&height=300&seq=service12&orientation=landscape',
      price: 'Contact for Quote'
    },
    {
      id: 13,
      name: 'Cladding Works',
      category: 'Construction',
      description: 'External and internal cladding installation services',
      image: 'https://readdy.ai/api/search-image?query=Modern%20building%20cladding%20installation%2C%20exterior%20wall%20cladding%20work%2C%20architectural%20cladding%20panels%2C%20professional%20cladding%20service%2C%20contemporary%20building%20facade&width=400&height=300&seq=service13&orientation=landscape',
      price: 'Contact for Quote'
    }
  ];

  const categories = ['All', 'Construction', 'Glass', 'Installation', 'HVAC', 'General', 'Finishing'];

  const filteredServices = activeFilter === 'All' 
    ? services 
    : services.filter(service => service.category === activeFilter);

  const handleOrderNow = (service: any) => {
    const message = `Hi! I would like to order the following service:

Service: ${service.name}
Description: ${service.description}
Price: ${service.price}

Please provide more details and availability.`;

    const whatsappUrl = `https://wa.me/971559508165?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <section className="py-20 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <h1 className="serif-title text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              Our Services
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive technical services delivered with expertise and precision. 
              From construction to maintenance, we've got you covered.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex flex-wrap justify-center gap-4 mb-12"
          >
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveFilter(category)}
                className={`px-6 py-3 rounded-full font-medium transition-all duration-300 ${
                  activeFilter === category
                    ? 'bg-[#018589] text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredServices.map((service, index) => (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={service.image}
                    alt={service.name}
                    className="w-full h-48 object-cover transition-transform duration-300 hover:scale-110"
                  />
                  <div className="absolute top-4 right-4">
                    <span className="bg-[#018589] text-white px-3 py-1 rounded-full text-sm font-medium">
                      {service.category}
                    </span>
                  </div>
                </div>
                
                <div className="p-6">
                  <h3 className="serif-title text-xl font-semibold text-gray-900 mb-2">
                    {service.name}
                  </h3>
                  <p className="text-gray-600 mb-4">
                    {service.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-[#018589] font-semibold">
                      {service.price}
                    </span>
                    <button
                      onClick={() => handleOrderNow(service)}
                      className="bg-[#018589] text-white px-6 py-2 rounded-full hover:bg-[#016b6f] transition-colors duration-300 flex items-center"
                    >
                      Order Now
                      <i className="ri-whatsapp-line ml-2"></i>
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mt-16 bg-gray-50 rounded-2xl p-12"
          >
            <h2 className="serif-title text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Need Custom Solutions?
            </h2>
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              Don't see what you're looking for? We offer custom technical services 
              tailored to your specific requirements. Contact us to discuss your project.
            </p>
            <a
              href="https://wa.me/971559508165"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-8 py-4 bg-[#018589] text-white font-semibold rounded-full hover:bg-[#016b6f] transition-all duration-300 transform hover:scale-105"
            >
              Contact Us on WhatsApp
              <i className="ri-whatsapp-line ml-2 text-lg"></i>
            </a>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}