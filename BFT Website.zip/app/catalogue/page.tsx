
'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import Header from '../../components/Header';
import Footer from '../../components/Footer';

export default function Catalogue() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState('All');

  const decorImages = [
    // Interior Design
    {
      id: 1,
      src: 'https://readdy.ai/api/search-image?query=Modern%20living%20room%20interior%20design%2C%20contemporary%20furniture%20arrangement%2C%20elegant%20decor%20elements%2C%20sophisticated%20color%20scheme%2C%20luxury%20home%20interior%2C%20professional%20interior%20decoration&width=400&height=600&seq=decor1&orientation=portrait',
      category: 'Interior',
      title: 'Modern Living Room Design'
    },
    {
      id: 2,
      src: 'https://readdy.ai/api/search-image?query=Luxury%20bedroom%20interior%20decoration%2C%20elegant%20bed%20setup%2C%20premium%20bedding%2C%20sophisticated%20lighting%2C%20modern%20bedroom%20design%2C%20high-end%20interior%20decor&width=600&height=400&seq=decor2&orientation=landscape',
      category: 'Interior',
      title: 'Luxury Bedroom Decor'
    },
    {
      id: 3,
      src: 'https://readdy.ai/api/search-image?query=Contemporary%20kitchen%20interior%20design%2C%20modern%20cabinetry%2C%20sleek%20countertops%2C%20professional%20kitchen%20decoration%2C%20elegant%20kitchen%20layout&width=400&height=300&seq=decor3&orientation=landscape',
      category: 'Interior',
      title: 'Contemporary Kitchen'
    },
    {
      id: 4,
      src: 'https://readdy.ai/api/search-image?query=Elegant%20dining%20room%20decoration%2C%20formal%20dining%20setup%2C%20luxury%20dining%20furniture%2C%20sophisticated%20table%20arrangement%2C%20premium%20dining%20decor&width=400&height=600&seq=decor4&orientation=portrait',
      category: 'Interior',
      title: 'Elegant Dining Room'
    },
    {
      id: 5,
      src: 'https://readdy.ai/api/search-image?query=Modern%20bathroom%20interior%20design%2C%20luxury%20bathroom%20fixtures%2C%20elegant%20tile%20work%2C%20contemporary%20bathroom%20decoration%2C%20spa-like%20bathroom%20decor&width=400&height=300&seq=decor5&orientation=landscape',
      category: 'Interior',
      title: 'Modern Bathroom Design'
    },
    
    // Wall Decoration
    {
      id: 6,
      src: 'https://readdy.ai/api/search-image?query=Creative%20wall%20art%20installation%2C%20modern%20wall%20decoration%2C%20artistic%20wall%20design%2C%20contemporary%20wall%20treatments%2C%20decorative%20wall%20panels&width=400&height=600&seq=decor6&orientation=portrait',
      category: 'Wall Art',
      title: 'Creative Wall Installation'
    },
    {
      id: 7,
      src: 'https://readdy.ai/api/search-image?query=Elegant%20wallpaper%20design%2C%20luxury%20wall%20covering%2C%20sophisticated%20wall%20decoration%2C%20premium%20wallpaper%20installation%2C%20modern%20wall%20treatments&width=600&height=400&seq=decor7&orientation=landscape',
      category: 'Wall Art',
      title: 'Luxury Wallpaper Design'
    },
    {
      id: 8,
      src: 'https://readdy.ai/api/search-image?query=Modern%20wall%20painting%20design%2C%20artistic%20wall%20colors%2C%20contemporary%20paint%20schemes%2C%20decorative%20wall%20painting%2C%20professional%20wall%20decoration&width=400&height=300&seq=decor8&orientation=landscape',
      category: 'Wall Art',
      title: 'Modern Wall Painting'
    },
    {
      id: 9,
      src: 'https://readdy.ai/api/search-image?query=3D%20wall%20panels%20installation%2C%20textured%20wall%20decoration%2C%20modern%20wall%20cladding%2C%20dimensional%20wall%20art%2C%20contemporary%20wall%20features&width=400&height=600&seq=decor9&orientation=portrait',
      category: 'Wall Art',
      title: '3D Wall Panels'
    },
    {
      id: 10,
      src: 'https://readdy.ai/api/search-image?query=Gallery%20wall%20arrangement%2C%20framed%20artwork%20display%2C%20photo%20wall%20decoration%2C%20artistic%20wall%20gallery%2C%20modern%20picture%20arrangement&width=600&height=400&seq=decor10&orientation=landscape',
      category: 'Wall Art',
      title: 'Gallery Wall Display'
    },

    // Ceiling Design
    {
      id: 11,
      src: 'https://readdy.ai/api/search-image?query=Modern%20false%20ceiling%20design%2C%20contemporary%20ceiling%20decoration%2C%20elegant%20ceiling%20treatment%2C%20sophisticated%20ceiling%20features%2C%20luxury%20ceiling%20work&width=600&height=400&seq=decor11&orientation=landscape',
      category: 'Ceiling',
      title: 'Modern False Ceiling'
    },
    {
      id: 12,
      src: 'https://readdy.ai/api/search-image?query=LED%20ceiling%20lighting%20design%2C%20modern%20ceiling%20lights%2C%20contemporary%20lighting%20fixtures%2C%20elegant%20ceiling%20illumination%2C%20sophisticated%20lighting%20decoration&width=400&height=300&seq=decor12&orientation=landscape',
      category: 'Ceiling',
      title: 'LED Ceiling Lighting'
    },
    {
      id: 13,
      src: 'https://readdy.ai/api/search-image?query=Gypsum%20ceiling%20decoration%2C%20ornate%20ceiling%20design%2C%20decorative%20ceiling%20molding%2C%20classical%20ceiling%20work%2C%20elegant%20ceiling%20details&width=400&height=600&seq=decor13&orientation=portrait',
      category: 'Ceiling',
      title: 'Gypsum Ceiling Work'
    },
    {
      id: 14,
      src: 'https://readdy.ai/api/search-image?query=Wooden%20ceiling%20design%2C%20natural%20wood%20ceiling%2C%20rustic%20ceiling%20decoration%2C%20timber%20ceiling%20work%2C%20warm%20wood%20ceiling%20treatment&width=600&height=400&seq=decor14&orientation=landscape',
      category: 'Ceiling',
      title: 'Wooden Ceiling Design'
    },
    {
      id: 15,
      src: 'https://readdy.ai/api/search-image?query=Suspended%20ceiling%20installation%2C%20drop%20ceiling%20design%2C%20modern%20suspended%20ceiling%2C%20office%20ceiling%20work%2C%20commercial%20ceiling%20decoration&width=400&height=300&seq=decor15&orientation=landscape',
      category: 'Ceiling',
      title: 'Suspended Ceiling'
    },

    // Flooring
    {
      id: 16,
      src: 'https://readdy.ai/api/search-image?query=Luxury%20marble%20flooring%2C%20premium%20marble%20installation%2C%20elegant%20marble%20floor%20design%2C%20sophisticated%20stone%20flooring%2C%20high-end%20marble%20work&width=600&height=400&seq=decor16&orientation=landscape',
      category: 'Flooring',
      title: 'Luxury Marble Flooring'
    },
    {
      id: 17,
      src: 'https://readdy.ai/api/search-image?query=Modern%20tile%20flooring%20design%2C%20contemporary%20ceramic%20tiles%2C%20elegant%20floor%20tile%20pattern%2C%20sophisticated%20tile%20installation%2C%20premium%20flooring%20work&width=400&height=600&seq=decor17&orientation=portrait',
      category: 'Flooring',
      title: 'Modern Tile Flooring'
    },
    {
      id: 18,
      src: 'https://readdy.ai/api/search-image?query=Hardwood%20flooring%20installation%2C%20natural%20wood%20floors%2C%20elegant%20wooden%20flooring%2C%20premium%20wood%20installation%2C%20classic%20hardwood%20design&width=400&height=300&seq=decor18&orientation=landscape',
      category: 'Flooring',
      title: 'Hardwood Flooring'
    },
    {
      id: 19,
      src: 'https://readdy.ai/api/search-image?query=Laminate%20flooring%20design%2C%20modern%20laminate%20installation%2C%20contemporary%20floor%20covering%2C%20durable%20flooring%20solution%2C%20stylish%20laminate%20work&width=600&height=400&seq=decor19&orientation=landscape',
      category: 'Flooring',
      title: 'Laminate Flooring'
    },
    {
      id: 20,
      src: 'https://readdy.ai/api/search-image?query=Vinyl%20flooring%20installation%2C%20luxury%20vinyl%20planks%2C%20modern%20vinyl%20floor%20design%2C%20waterproof%20flooring%2C%20contemporary%20vinyl%20work&width=400&height=300&seq=decor20&orientation=landscape',
      category: 'Flooring',
      title: 'Vinyl Flooring'
    },

    // Lighting Design
    {
      id: 21,
      src: 'https://readdy.ai/api/search-image?query=Modern%20chandelier%20installation%2C%20elegant%20lighting%20fixture%2C%20luxury%20chandelier%20design%2C%20sophisticated%20pendant%20lighting%2C%20decorative%20ceiling%20light&width=400&height=600&seq=decor21&orientation=portrait',
      category: 'Lighting',
      title: 'Modern Chandelier'
    },
    {
      id: 22,
      src: 'https://readdy.ai/api/search-image?query=LED%20strip%20lighting%20design%2C%20modern%20accent%20lighting%2C%20contemporary%20LED%20installation%2C%20ambient%20lighting%20decoration%2C%20sophisticated%20light%20strips&width=600&height=400&seq=decor22&orientation=landscape',
      category: 'Lighting',
      title: 'LED Strip Lighting'
    },
    {
      id: 23,
      src: 'https://readdy.ai/api/search-image?query=Pendant%20light%20arrangement%2C%20modern%20hanging%20lights%2C%20contemporary%20pendant%20fixtures%2C%20elegant%20suspended%20lighting%2C%20stylish%20pendant%20design&width=400&height=300&seq=decor23&orientation=landscape',
      category: 'Lighting',
      title: 'Pendant Light Design'
    },
    {
      id: 24,
      src: 'https://readdy.ai/api/search-image?query=Recessed%20lighting%20installation%2C%20ceiling%20spotlights%2C%20modern%20downlights%2C%20contemporary%20ceiling%20lights%2C%20elegant%20recessed%20fixtures&width=400&height=600&seq=decor24&orientation=portrait',
      category: 'Lighting',
      title: 'Recessed Lighting'
    },
    {
      id: 25,
      src: 'https://readdy.ai/api/search-image?query=Wall%20sconce%20lighting%2C%20modern%20wall%20lights%2C%20contemporary%20wall%20fixtures%2C%20elegant%20wall%20lamps%2C%20sophisticated%20wall%20lighting&width=600&height=400&seq=decor25&orientation=landscape',
      category: 'Lighting',
      title: 'Wall Sconce Lighting'
    },

    // Furniture & Accessories
    {
      id: 26,
      src: 'https://readdy.ai/api/search-image?query=Modern%20sofa%20arrangement%2C%20contemporary%20living%20room%20furniture%2C%20elegant%20seating%20design%2C%20luxury%20furniture%20setup%2C%20sophisticated%20furniture%20decoration&width=600&height=400&seq=decor26&orientation=landscape',
      category: 'Furniture',
      title: 'Modern Sofa Arrangement'
    },
    {
      id: 27,
      src: 'https://readdy.ai/api/search-image?query=Custom%20wardrobe%20design%2C%20built-in%20closet%2C%20modern%20storage%20solution%2C%20elegant%20wardrobe%20installation%2C%20sophisticated%20bedroom%20storage&width=400&height=600&seq=decor27&orientation=portrait',
      category: 'Furniture',
      title: 'Custom Wardrobe'
    },
    {
      id: 28,
      src: 'https://readdy.ai/api/search-image?query=Modern%20dining%20table%20setup%2C%20contemporary%20dining%20furniture%2C%20elegant%20table%20arrangement%2C%20luxury%20dining%20set%2C%20sophisticated%20dining%20decoration&width=400&height=300&seq=decor28&orientation=landscape',
      category: 'Furniture',
      title: 'Modern Dining Setup'
    },
    {
      id: 29,
      src: 'https://readdy.ai/api/search-image?query=Built-in%20bookshelf%20design%2C%20custom%20library%20shelving%2C%20modern%20storage%20unit%2C%20elegant%20book%20display%2C%20sophisticated%20shelving%20system&width=400&height=600&seq=decor29&orientation=portrait',
      category: 'Furniture',
      title: 'Built-in Bookshelf'
    },
    {
      id: 30,
      src: 'https://readdy.ai/api/search-image?query=Modern%20coffee%20table%20decoration%2C%20contemporary%20center%20table%2C%20elegant%20table%20styling%2C%20luxury%20coffee%20table%20setup%2C%20sophisticated%20living%20room%20accent&width=600&height=400&seq=decor30&orientation=landscape',
      category: 'Furniture',
      title: 'Modern Coffee Table'
    },

    // Window Treatments
    {
      id: 31,
      src: 'https://readdy.ai/api/search-image?query=Luxury%20curtain%20installation%2C%20elegant%20window%20drapes%2C%20sophisticated%20curtain%20design%2C%20premium%20window%20treatments%2C%20modern%20curtain%20decoration&width=400&height=600&seq=decor31&orientation=portrait',
      category: 'Windows',
      title: 'Luxury Curtains'
    },
    {
      id: 32,
      src: 'https://readdy.ai/api/search-image?query=Modern%20blinds%20installation%2C%20contemporary%20window%20blinds%2C%20sleek%20venetian%20blinds%2C%20elegant%20window%20covering%2C%20sophisticated%20blind%20design&width=600&height=400&seq=decor32&orientation=landscape',
      category: 'Windows',
      title: 'Modern Blinds'
    },
    {
      id: 33,
      src: 'https://readdy.ai/api/search-image?query=Roman%20shade%20window%20treatment%2C%20elegant%20fabric%20shades%2C%20contemporary%20window%20shades%2C%20luxury%20roman%20blinds%2C%20sophisticated%20shade%20installation&width=400&height=300&seq=decor33&orientation=landscape',
      category: 'Windows',
      title: 'Roman Shades'
    },
    {
      id: 34,
      src: 'https://readdy.ai/api/search-image?query=Sheer%20curtain%20design%2C%20light%20filtering%20curtains%2C%20elegant%20sheer%20panels%2C%20modern%20window%20sheers%2C%20sophisticated%20translucent%20curtains&width=400&height=600&seq=decor34&orientation=portrait',
      category: 'Windows',
      title: 'Sheer Curtains'
    },
    {
      id: 35,
      src: 'https://readdy.ai/api/search-image?query=Motorized%20blinds%20installation%2C%20smart%20window%20treatments%2C%20automated%20blind%20system%2C%20modern%20electronic%20blinds%2C%20high-tech%20window%20covering&width=600&height=400&seq=decor35&orientation=landscape',
      category: 'Windows',
      title: 'Motorized Blinds'
    },

    // Decorative Elements
    {
      id: 36,
      src: 'https://readdy.ai/api/search-image?query=Modern%20mirror%20decoration%2C%20decorative%20wall%20mirrors%2C%20contemporary%20mirror%20design%2C%20elegant%20mirror%20arrangement%2C%20sophisticated%20mirror%20installation&width=400&height=600&seq=decor36&orientation=portrait',
      category: 'Decor',
      title: 'Decorative Mirrors'
    },
    {
      id: 37,
      src: 'https://readdy.ai/api/search-image?query=Indoor%20plant%20decoration%2C%20modern%20plant%20arrangement%2C%20contemporary%20greenery%2C%20elegant%20plant%20display%2C%20sophisticated%20indoor%20garden&width=600&height=400&seq=decor37&orientation=landscape',
      category: 'Decor',
      title: 'Indoor Plant Decor'
    },
    {
      id: 38,
      src: 'https://readdy.ai/api/search-image?query=Decorative%20vase%20collection%2C%20modern%20ceramic%20vases%2C%20contemporary%20pottery%20display%2C%20elegant%20vase%20arrangement%2C%20sophisticated%20decorative%20objects&width=400&height=300&seq=decor38&orientation=landscape',
      category: 'Decor',
      title: 'Decorative Vases'
    },
    {
      id: 39,
      src: 'https://readdy.ai/api/search-image?query=Modern%20sculpture%20display%2C%20contemporary%20art%20pieces%2C%20elegant%20sculptural%20elements%2C%20sophisticated%20art%20decoration%2C%20luxury%20decorative%20objects&width=400&height=600&seq=decor39&orientation=portrait',
      category: 'Decor',
      title: 'Modern Sculptures'
    },
    {
      id: 40,
      src: 'https://readdy.ai/api/search-image?query=Decorative%20pillow%20arrangement%2C%20modern%20throw%20pillows%2C%20contemporary%20cushion%20design%2C%20elegant%20pillow%20styling%2C%20sophisticated%20textile%20decoration&width=600&height=400&seq=decor40&orientation=landscape',
      category: 'Decor',
      title: 'Decorative Pillows'
    },

    // Office Decor
    {
      id: 41,
      src: 'https://readdy.ai/api/search-image?query=Modern%20office%20interior%20design%2C%20contemporary%20workspace%20decoration%2C%20elegant%20office%20layout%2C%20professional%20office%20decor%2C%20sophisticated%20business%20interior&width=600&height=400&seq=decor41&orientation=landscape',
      category: 'Office',
      title: 'Modern Office Design'
    },
    {
      id: 42,
      src: 'https://readdy.ai/api/search-image?query=Executive%20office%20decoration%2C%20luxury%20office%20interior%2C%20premium%20office%20furniture%2C%20sophisticated%20executive%20space%2C%20high-end%20office%20design&width=400&height=600&seq=decor42&orientation=portrait',
      category: 'Office',
      title: 'Executive Office'
    },
    {
      id: 43,
      src: 'https://readdy.ai/api/search-image?query=Meeting%20room%20design%2C%20conference%20room%20decoration%2C%20modern%20boardroom%2C%20professional%20meeting%20space%2C%20elegant%20conference%20room%20setup&width=400&height=300&seq=decor43&orientation=landscape',
      category: 'Office',
      title: 'Meeting Room Design'
    },
    {
      id: 44,
      src: 'https://readdy.ai/api/search-image?query=Reception%20area%20decoration%2C%20modern%20lobby%20design%2C%20contemporary%20reception%20desk%2C%20elegant%20entrance%20area%2C%20sophisticated%20welcome%20space&width=400&height=600&seq=decor44&orientation=portrait',
      category: 'Office',
      title: 'Reception Area'
    },
    {
      id: 45,
      src: 'https://readdy.ai/api/search-image?query=Open%20office%20layout%2C%20modern%20workspace%20design%2C%20contemporary%20office%20pods%2C%20collaborative%20work%20environment%2C%20flexible%20office%20decoration&width=600&height=400&seq=decor45&orientation=landscape',
      category: 'Office',
      title: 'Open Office Layout'
    },

    // Kitchen Design
    {
      id: 46,
      src: 'https://readdy.ai/api/search-image?query=Modern%20kitchen%20island%20design%2C%20contemporary%20kitchen%20center%2C%20elegant%20island%20setup%2C%20luxury%20kitchen%20island%2C%20sophisticated%20kitchen%20decoration&width=600&height=400&seq=decor46&orientation=landscape',
      category: 'Kitchen',
      title: 'Modern Kitchen Island'
    },
    {
      id: 47,
      src: 'https://readdy.ai/api/search-image?query=Kitchen%20backsplash%20design%2C%20modern%20tile%20backsplash%2C%20contemporary%20kitchen%20wall%2C%20elegant%20backsplash%20installation%2C%20sophisticated%20kitchen%20tiling&width=400&height=300&seq=decor47&orientation=landscape',
      category: 'Kitchen',
      title: 'Kitchen Backsplash'
    },
    {
      id: 48,
      src: 'https://readdy.ai/api/search-image?query=Custom%20kitchen%20cabinets%2C%20modern%20cabinetry%20design%2C%20contemporary%20kitchen%20storage%2C%20elegant%20cabinet%20installation%2C%20sophisticated%20kitchen%20units&width=400&height=600&seq=decor48&orientation=portrait',
      category: 'Kitchen',
      title: 'Custom Kitchen Cabinets'
    },
    {
      id: 49,
      src: 'https://readdy.ai/api/search-image?query=Kitchen%20countertop%20design%2C%20modern%20counter%20installation%2C%20contemporary%20worktop%2C%20elegant%20kitchen%20surface%2C%20luxury%20countertop%20material&width=600&height=400&seq=decor49&orientation=landscape',
      category: 'Kitchen',
      title: 'Kitchen Countertops'
    },
    {
      id: 50,
      src: 'https://readdy.ai/api/search-image?query=Kitchen%20lighting%20design%2C%20modern%20kitchen%20lights%2C%20contemporary%20task%20lighting%2C%20elegant%20kitchen%20illumination%2C%20sophisticated%20culinary%20lighting&width=400&height=300&seq=decor50&orientation=landscape',
      category: 'Kitchen',
      title: 'Kitchen Lighting'
    },

    // Bathroom Design
    {
      id: 51,
      src: 'https://readdy.ai/api/search-image?query=Luxury%20bathroom%20vanity%2C%20modern%20bathroom%20cabinet%2C%20contemporary%20vanity%20design%2C%20elegant%20bathroom%20furniture%2C%20sophisticated%20bathroom%20storage&width=400&height=600&seq=decor51&orientation=portrait',
      category: 'Bathroom',
      title: 'Luxury Bathroom Vanity'
    },
    {
      id: 52,
      src: 'https://readdy.ai/api/search-image?query=Modern%20shower%20design%2C%20contemporary%20shower%20enclosure%2C%20elegant%20glass%20shower%2C%20luxury%20shower%20installation%2C%20sophisticated%20bathroom%20shower&width=600&height=400&seq=decor52&orientation=landscape',
      category: 'Bathroom',
      title: 'Modern Shower Design'
    },
    {
      id: 53,
      src: 'https://readdy.ai/api/search-image?query=Bathroom%20tile%20design%2C%20modern%20bathroom%20tiling%2C%20contemporary%20tile%20pattern%2C%20elegant%20bathroom%20wall%2C%20sophisticated%20tile%20installation&width=400&height=300&seq=decor53&orientation=landscape',
      category: 'Bathroom',
      title: 'Bathroom Tile Design'
    },
    {
      id: 54,
      src: 'https://readdy.ai/api/search-image?query=Freestanding%20bathtub%2C%20modern%20soaking%20tub%2C%20contemporary%20bath%20design%2C%20elegant%20bathroom%20centerpiece%2C%20luxury%20bathtub%20installation&width=400&height=600&seq=decor54&orientation=portrait',
      category: 'Bathroom',
      title: 'Freestanding Bathtub'
    },
    {
      id: 55,
      src: 'https://readdy.ai/api/search-image?query=Bathroom%20mirror%20design%2C%20modern%20vanity%20mirror%2C%20contemporary%20bathroom%20lighting%2C%20elegant%20mirror%20installation%2C%20sophisticated%20bathroom%20reflection&width=600&height=400&seq=decor55&orientation=landscape',
      category: 'Bathroom',
      title: 'Bathroom Mirror'
    },

    // Bedroom Design
    {
      id: 56,
      src: 'https://readdy.ai/api/search-image?query=Modern%20headboard%20design%2C%20contemporary%20bed%20head%2C%20elegant%20bedroom%20focal%20point%2C%20luxury%20headboard%20installation%2C%20sophisticated%20bedroom%20decoration&width=400&height=600&seq=decor56&orientation=portrait',
      category: 'Bedroom',
      title: 'Modern Headboard'
    },
    {
      id: 57,
      src: 'https://readdy.ai/api/search-image?query=Bedroom%20lighting%20design%2C%20modern%20bedside%20lamps%2C%20contemporary%20bedroom%20illumination%2C%20elegant%20bedroom%20lights%2C%20sophisticated%20nighttime%20lighting&width=600&height=400&seq=decor57&orientation=landscape',
      category: 'Bedroom',
      title: 'Bedroom Lighting'
    },
    {
      id: 58,
      src: 'https://readdy.ai/api/search-image?query=Walk-in%20closet%20design%2C%20modern%20dressing%20room%2C%20contemporary%20wardrobe%20space%2C%20elegant%20closet%20organization%2C%20luxury%20storage%20solution&width=400&height=300&seq=decor58&orientation=landscape',
      category: 'Bedroom',
      title: 'Walk-in Closet'
    },
    {
      id: 59,
      src: 'https://readdy.ai/api/search-image?query=Bedroom%20accent%20wall%2C%20modern%20feature%20wall%2C%20contemporary%20wall%20design%2C%20elegant%20bedroom%20backdrop%2C%20sophisticated%20wall%20treatment&width=400&height=600&seq=decor59&orientation=portrait',
      category: 'Bedroom',
      title: 'Bedroom Accent Wall'
    },
    {
      id: 60,
      src: 'https://readdy.ai/api/search-image?query=Master%20bedroom%20suite%2C%20luxury%20bedroom%20design%2C%20contemporary%20master%20room%2C%20elegant%20bedroom%20layout%2C%20sophisticated%20bedroom%20interior&width=600&height=400&seq=decor60&orientation=landscape',
      category: 'Bedroom',
      title: 'Master Bedroom Suite'
    },

    // Living Room Design
    {
      id: 61,
      src: 'https://readdy.ai/api/search-image?query=Modern%20fireplace%20design%2C%20contemporary%20hearth%2C%20elegant%20fireplace%20surround%2C%20luxury%20fireplace%20installation%2C%20sophisticated%20living%20room%20focal%20point&width=400&height=600&seq=decor61&orientation=portrait',
      category: 'Living',
      title: 'Modern Fireplace'
    },
    {
      id: 62,
      src: 'https://readdy.ai/api/search-image?query=Entertainment%20center%20design%2C%20modern%20TV%20wall%2C%20contemporary%20media%20unit%2C%20elegant%20entertainment%20setup%2C%20sophisticated%20living%20room%20technology&width=600&height=400&seq=decor62&orientation=landscape',
      category: 'Living',
      title: 'Entertainment Center'
    },
    {
      id: 63,
      src: 'https://readdy.ai/api/search-image?query=Living%20room%20area%20rug%2C%20modern%20carpet%20design%2C%20contemporary%20floor%20covering%2C%20elegant%20rug%20placement%2C%20sophisticated%20textile%20decoration&width=400&height=300&seq=decor63&orientation=landscape',
      category: 'Living',
      title: 'Living Room Rug'
    },
    {
      id: 64,
      src: 'https://readdy.ai/api/search-image?query=Modern%20sectional%20sofa%2C%20contemporary%20L-shaped%20seating%2C%20elegant%20corner%20sofa%2C%20luxury%20sectional%20design%2C%20sophisticated%20living%20room%20furniture&width=400&height=600&seq=decor64&orientation=portrait',
      category: 'Living',
      title: 'Modern Sectional'
    },
    {
      id: 65,
      src: 'https://readdy.ai/api/search-image?query=Living%20room%20built-ins%2C%20custom%20shelving%20unit%2C%20contemporary%20storage%20wall%2C%20elegant%20display%20case%2C%20sophisticated%20living%20room%20organization&width=600&height=400&seq=decor65&orientation=landscape',
      category: 'Living',
      title: 'Living Room Built-ins'
    },

    // Outdoor Design
    {
      id: 66,
      src: 'https://readdy.ai/api/search-image?query=Modern%20outdoor%20patio%2C%20contemporary%20deck%20design%2C%20elegant%20outdoor%20living%2C%20luxury%20patio%20furniture%2C%20sophisticated%20outdoor%20decoration&width=600&height=400&seq=decor66&orientation=landscape',
      category: 'Outdoor',
      title: 'Modern Outdoor Patio'
    },
    {
      id: 67,
      src: 'https://readdy.ai/api/search-image?query=Garden%20landscape%20design%2C%20modern%20outdoor%20landscaping%2C%20contemporary%20garden%20layout%2C%20elegant%20outdoor%20space%2C%20sophisticated%20garden%20decoration&width=400&height=600&seq=decor67&orientation=portrait',
      category: 'Outdoor',
      title: 'Garden Landscape'
    },
    {
      id: 68,
      src: 'https://readdy.ai/api/search-image?query=Outdoor%20lighting%20design%2C%20modern%20garden%20lights%2C%20contemporary%20landscape%20illumination%2C%20elegant%20outdoor%20fixtures%2C%20sophisticated%20exterior%20lighting&width=400&height=300&seq=decor68&orientation=landscape',
      category: 'Outdoor',
      title: 'Outdoor Lighting'
    },
    {
      id: 69,
      src: 'https://readdy.ai/api/search-image?query=Modern%20pergola%20design%2C%20contemporary%20outdoor%20structure%2C%20elegant%20garden%20pergola%2C%20luxury%20outdoor%20covering%2C%20sophisticated%20patio%20enhancement&width=400&height=600&seq=decor69&orientation=portrait',
      category: 'Outdoor',
      title: 'Modern Pergola'
    },
    {
      id: 70,
      src: 'https://readdy.ai/api/search-image?query=Outdoor%20kitchen%20design%2C%20modern%20BBQ%20area%2C%20contemporary%20outdoor%20cooking%2C%20elegant%20patio%20kitchen%2C%20sophisticated%20outdoor%20dining&width=600&height=400&seq=decor70&orientation=landscape',
      category: 'Outdoor',
      title: 'Outdoor Kitchen'
    },

    // Commercial Design
    {
      id: 71,
      src: 'https://readdy.ai/api/search-image?query=Modern%20restaurant%20interior%2C%20contemporary%20dining%20establishment%2C%20elegant%20restaurant%20design%2C%20luxury%20restaurant%20decoration%2C%20sophisticated%20commercial%20space&width=600&height=400&seq=decor71&orientation=landscape',
      category: 'Commercial',
      title: 'Restaurant Interior'
    },
    {
      id: 72,
      src: 'https://readdy.ai/api/search-image?query=Retail%20store%20design%2C%20modern%20shop%20interior%2C%20contemporary%20retail%20space%2C%20elegant%20store%20layout%2C%20sophisticated%20commercial%20decoration&width=400&height=600&seq=decor72&orientation=portrait',
      category: 'Commercial',
      title: 'Retail Store Design'
    },
    {
      id: 73,
      src: 'https://readdy.ai/api/search-image?query=Hotel%20lobby%20design%2C%20modern%20hospitality%20interior%2C%20contemporary%20hotel%20entrance%2C%20elegant%20reception%20area%2C%20luxury%20hotel%20decoration&width=400&height=300&seq=decor73&orientation=landscape',
      category: 'Commercial',
      title: 'Hotel Lobby'
    },
    {
      id: 74,
      src: 'https://readdy.ai/api/search-image?query=Modern%20cafe%20interior%2C%20contemporary%20coffee%20shop%2C%20elegant%20cafe%20design%2C%20stylish%20coffee%20house%2C%20sophisticated%20commercial%20space&width=400&height=600&seq=decor74&orientation=portrait',
      category: 'Commercial',
      title: 'Modern Cafe'
    },
    {
      id: 75,
      src: 'https://readdy.ai/api/search-image?query=Showroom%20design%2C%20modern%20display%20space%2C%20contemporary%20exhibition%20area%2C%20elegant%20product%20showcase%2C%20sophisticated%20commercial%20display&width=600&height=400&seq=decor75&orientation=landscape',
      category: 'Commercial',
      title: 'Showroom Design'
    },

    // Additional Interior Designs
    {
      id: 76,
      src: 'https://readdy.ai/api/search-image?query=Modern%20hallway%20design%2C%20contemporary%20corridor%20decoration%2C%20elegant%20entrance%20hall%2C%20sophisticated%20passage%20design%2C%20luxury%20hallway%20treatment&width=400&height=600&seq=decor76&orientation=portrait',
      category: 'Interior',
      title: 'Modern Hallway'
    },
    {
      id: 77,
      src: 'https://readdy.ai/api/search-image?query=Home%20library%20design%2C%20modern%20reading%20room%2C%20contemporary%20book%20space%2C%20elegant%20study%20area%2C%20sophisticated%20home%20office%20library&width=600&height=400&seq=decor77&orientation=landscape',
      category: 'Interior',
      title: 'Home Library'
    },
    {
      id: 78,
      src: 'https://readdy.ai/api/search-image?query=Modern%20staircase%20design%2C%20contemporary%20stair%20railing%2C%20elegant%20stairway%2C%20luxury%20stair%20installation%2C%20sophisticated%20staircase%20decoration&width=400&height=300&seq=decor78&orientation=landscape',
      category: 'Interior',
      title: 'Modern Staircase'
    },
    {
      id: 79,
      src: 'https://readdy.ai/api/search-image?query=Mudroom%20design%2C%20modern%20entryway%20storage%2C%20contemporary%20coat%20room%2C%20elegant%20entrance%20organization%2C%20sophisticated%20entry%20space&width=400&height=600&seq=decor79&orientation=portrait',
      category: 'Interior',
      title: 'Mudroom Design'
    },
    {
      id: 80,
      src: 'https://readdy.ai/api/search-image?query=Powder%20room%20design%2C%20modern%20guest%20bathroom%2C%20contemporary%20half%20bath%2C%20elegant%20small%20bathroom%2C%20sophisticated%20powder%20room%20decoration&width=600&height=400&seq=decor80&orientation=landscape',
      category: 'Interior',
      title: 'Powder Room'
    },

    // More Wall Art
    {
      id: 81,
      src: 'https://readdy.ai/api/search-image?query=Modern%20mural%20painting%2C%20contemporary%20wall%20art%2C%20artistic%20wall%20mural%2C%20creative%20wall%20decoration%2C%20sophisticated%20painted%20wall%20design&width=400&height=600&seq=decor81&orientation=portrait',
      category: 'Wall Art',
      title: 'Modern Mural'
    },
    {
      id: 82,
      src: 'https://readdy.ai/api/search-image?query=Accent%20wall%20design%2C%20modern%20feature%20wall%2C%20contemporary%20wall%20treatment%2C%20elegant%20wall%20highlight%2C%20sophisticated%20wall%20decoration&width=600&height=400&seq=decor82&orientation=landscape',
      category: 'Wall Art',
      title: 'Accent Wall'
    },
    {
      id: 83,
      src: 'https://readdy.ai/api/search-image?query=Wall%20shelving%20design%2C%20modern%20floating%20shelves%2C%20contemporary%20wall%20storage%2C%20elegant%20shelf%20arrangement%2C%20sophisticated%20wall%20organization&width=400&height=300&seq=decor83&orientation=landscape',
      category: 'Wall Art',
      title: 'Wall Shelving'
    },
    {
      id: 84,
      src: 'https://readdy.ai/api/search-image?query=Decorative%20wall%20molding%2C%20modern%20trim%20work%2C%20contemporary%20wall%20details%2C%20elegant%20architectural%20elements%2C%20sophisticated%20wall%20finishing&width=400&height=600&seq=decor84&orientation=portrait',
      category: 'Wall Art',
      title: 'Decorative Molding'
    },
    {
      id: 85,
      src: 'https://readdy.ai/api/search-image?query=Wall%20niche%20design%2C%20modern%20built-in%20alcove%2C%20contemporary%20wall%20recess%2C%20elegant%20display%20niche%2C%20sophisticated%20wall%20feature&width=600&height=400&seq=decor85&orientation=landscape',
      category: 'Wall Art',
      title: 'Wall Niche'
    },

    // More Ceiling Designs
    {
      id: 86,
      src: 'https://readdy.ai/api/search-image?query=Coffered%20ceiling%20design%2C%20modern%20ceiling%20panels%2C%20contemporary%20ceiling%20treatment%2C%20elegant%20ceiling%20detail%2C%20sophisticated%20ceiling%20architecture&width=600&height=400&seq=decor86&orientation=landscape',
      category: 'Ceiling',
      title: 'Coffered Ceiling'
    },
    {
      id: 87,
      src: 'https://readdy.ai/api/search-image?query=Vaulted%20ceiling%20design%2C%20modern%20high%20ceiling%2C%20contemporary%20cathedral%20ceiling%2C%20elegant%20ceiling%20height%2C%20sophisticated%20ceiling%20structure&width=400&height=600&seq=decor87&orientation=portrait',
      category: 'Ceiling',
      title: 'Vaulted Ceiling'
    },
    {
      id: 88,
      src: 'https://readdy.ai/api/search-image?query=Ceiling%20medallion%20design%2C%20decorative%20ceiling%20rose%2C%20ornate%20ceiling%20detail%2C%20elegant%20ceiling%20centerpiece%2C%20sophisticated%20ceiling%20ornament&width=400&height=300&seq=decor88&orientation=landscape',
      category: 'Ceiling',
      title: 'Ceiling Medallion'
    },
    {
      id: 89,
      src: 'https://readdy.ai/api/search-image?query=Beam%20ceiling%20design%2C%20exposed%20wooden%20beams%2C%20rustic%20ceiling%20treatment%2C%20natural%20wood%20ceiling%2C%20countryside%20ceiling%20decoration&width=400&height=600&seq=decor89&orientation=portrait',
      category: 'Ceiling',
      title: 'Beam Ceiling'
    },
    {
      id: 90,
      src: 'https://readdy.ai/api/search-image?query=Acoustic%20ceiling%20design%2C%20sound%20dampening%20ceiling%2C%20modern%20acoustic%20panels%2C%20contemporary%20noise%20control%2C%20sophisticated%20ceiling%20treatment&width=600&height=400&seq=decor90&orientation=landscape',
      category: 'Ceiling',
      title: 'Acoustic Ceiling'
    },

    // More Lighting
    {
      id: 91,
      src: 'https://readdy.ai/api/search-image?query=Track%20lighting%20system%2C%20modern%20ceiling%20tracks%2C%20contemporary%20spot%20lighting%2C%20elegant%20directional%20lights%2C%20sophisticated%20lighting%20rail&width=600&height=400&seq=decor91&orientation=landscape',
      category: 'Lighting',
      title: 'Track Lighting'
    },
    {
      id: 92,
      src: 'https://readdy.ai/api/search-image?query=Floor%20lamp%20design%2C%20modern%20standing%20lamp%2C%20contemporary%20floor%20lighting%2C%20elegant%20tall%20lamp%2C%20sophisticated%20floor%20fixture&width=400&height=600&seq=decor92&orientation=portrait',
      category: 'Lighting',
      title: 'Floor Lamp'
    },
    {
      id: 93,
      src: 'https://readdy.ai/api/search-image?query=Table%20lamp%20collection%2C%20modern%20desk%20lamps%2C%20contemporary%20bedside%20lighting%2C%20elegant%20lamp%20arrangement%2C%20sophisticated%20table%20fixtures&width=400&height=300&seq=decor93&orientation=landscape',
      category: 'Lighting',
      title: 'Table Lamps'
    },
    {
      id: 94,
      src: 'https://readdy.ai/api/search-image?query=Outdoor%20string%20lights%2C%20modern%20patio%20lighting%2C%20contemporary%20garden%20illumination%2C%20elegant%20outdoor%20ambiance%2C%20sophisticated%20exterior%20decoration&width=400&height=600&seq=decor94&orientation=portrait',
      category: 'Lighting',
      title: 'String Lights'
    },
    {
      id: 95,
      src: 'https://readdy.ai/api/search-image?query=Smart%20lighting%20system%2C%20modern%20home%20automation%2C%20contemporary%20intelligent%20lighting%2C%20elegant%20smart%20controls%2C%20sophisticated%20lighting%20technology&width=600&height=400&seq=decor95&orientation=landscape',
      category: 'Lighting',
      title: 'Smart Lighting'
    },

    // Final Set
    {
      id: 96,
      src: 'https://readdy.ai/api/search-image?query=Modern%20room%20divider%2C%20contemporary%20space%20partition%2C%20elegant%20room%20separator%2C%20sophisticated%20privacy%20screen%2C%20stylish%20interior%20division&width=400&height=600&seq=decor96&orientation=portrait',
      category: 'Decor',
      title: 'Room Divider'
    },
    {
      id: 97,
      src: 'https://readdy.ai/api/search-image?query=Decorative%20ceiling%20fan%2C%20modern%20ventilation%20design%2C%20contemporary%20ceiling%20fan%2C%20elegant%20air%20circulation%2C%20sophisticated%20cooling%20solution&width=600&height=400&seq=decor97&orientation=landscape',
      category: 'Ceiling',
      title: 'Decorative Fan'
    },
    {
      id: 98,
      src: 'https://readdy.ai/api/search-image?query=Modern%20home%20bar%20design%2C%20contemporary%20wet%20bar%2C%20elegant%20home%20entertainment%2C%20luxury%20bar%20setup%2C%20sophisticated%20home%20hospitality&width=400&height=300&seq=decor98&orientation=landscape',
      category: 'Interior',
      title: 'Home Bar'
    },
    {
      id: 99,
      src: 'https://readdy.ai/api/search-image?query=Wine%20cellar%20design%2C%20modern%20wine%20storage%2C%20contemporary%20wine%20room%2C%20elegant%20wine%20display%2C%20sophisticated%20wine%20collection&width=400&height=600&seq=decor99&orientation=portrait',
      category: 'Interior',
      title: 'Wine Cellar'
    },
    {
      id: 100,
      src: 'https://readdy.ai/api/search-image?query=Home%20theater%20design%2C%20modern%20media%20room%2C%20contemporary%20entertainment%20space%2C%20elegant%20home%20cinema%2C%20sophisticated%20audiovisual%20room&width=600&height=400&seq=decor100&orientation=landscape',
      category: 'Interior',
      title: 'Home Theater'
    },
    {
      id: 101,
      src: 'https://readdy.ai/api/search-image?query=Luxury%20spa%20bathroom%2C%20modern%20wellness%20space%2C%20contemporary%20relaxation%20room%2C%20elegant%20spa%20design%2C%20sophisticated%20wellness%20interior&width=400&height=600&seq=decor101&orientation=portrait',
      category: 'Bathroom',
      title: 'Spa Bathroom'
    },
    {
      id: 102,
      src: 'https://readdy.ai/api/search-image?query=Modern%20gym%20interior%2C%20contemporary%20home%20fitness%2C%20elegant%20exercise%20room%2C%20luxury%20workout%20space%2C%20sophisticated%20fitness%20design&width=600&height=400&seq=decor102&orientation=landscape',
      category: 'Interior',
      title: 'Home Gym'
    },
    {
      id: 103,
      src: 'https://readdy.ai/api/search-image?query=Craft%20room%20design%2C%20modern%20hobby%20space%2C%20contemporary%20creative%20room%2C%20elegant%20art%20studio%2C%20sophisticated%20workspace%20for%20creativity&width=400&height=300&seq=decor103&orientation=landscape',
      category: 'Interior',
      title: 'Craft Room'
    },
    {
      id: 104,
      src: 'https://readdy.ai/api/search-image?query=Kids%20playroom%20design%2C%20modern%20children%20space%2C%20contemporary%20play%20area%2C%20colorful%20kid%20room%2C%20fun%20and%20safe%20play%20environment&width=400&height=600&seq=decor104&orientation=portrait',
      category: 'Interior',
      title: 'Kids Playroom'
    },
    {
      id: 105,
      src: 'https://readdy.ai/api/search-image?query=Modern%20laundry%20room%2C%20contemporary%20utility%20space%2C%20elegant%20laundry%20design%2C%20organized%20washing%20area%2C%20sophisticated%20home%20utility%20room&width=600&height=400&seq=decor105&orientation=landscape',
      category: 'Interior',
      title: 'Laundry Room'
    }
  ];

  const categories = ['All', 'Interior', 'Wall Art', 'Ceiling', 'Flooring', 'Lighting', 'Furniture', 'Windows', 'Decor', 'Office', 'Kitchen', 'Bathroom', 'Bedroom', 'Living', 'Outdoor', 'Commercial'];

  const filteredImages = activeFilter === 'All' 
    ? decorImages 
    : decorImages.filter(image => image.category === activeFilter);

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <section className="py-20 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <h1 className="serif-title text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              Decor Catalogue
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Explore our extensive collection of decoration and interior design projects. 
              Get inspired by over 100 stunning decor ideas and implementations.
            </p>
            <div className="mt-8 bg-[#018589] text-white px-6 py-3 rounded-full inline-block">
              <span className="font-medium">Total Items: {decorImages.length}</span>
            </div>
          </motion.div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveFilter(category)}
                className={`px-6 py-2 rounded-full transition-all duration-300 ${
                  activeFilter === category
                    ? 'bg-[#018589] text-white shadow-lg'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Image Gallery */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
            {filteredImages.map((image) => (
              <motion.div
                key={image.id}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="overflow-hidden rounded-xl shadow-lg cursor-pointer"
                onClick={() => setSelectedImage(image.src)}
              >
                <div className="relative pb-[125%]"> {/* 4:5 aspect ratio container */}
                  <img
                    src={image.src}
                    alt={image.title}
                    className="absolute inset-0 w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.src = '/placeholder-image.jpg';
                      e.currentTarget.alt = 'Image not available';
                    }}
                  />
                </div>
                <div className="p-4 bg-gray-50">
                  <h3 className="font-semibold text-lg text-gray-800">{image.title}</h3>
                  <p className="text-gray-600">{image.category}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Modal for selected image */}
      {selectedImage && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4"
          onClick={() => setSelectedImage(null)}
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="relative max-w-4xl max-h-full"
            onClick={(e) => e.stopPropagation()}
          >
            <img 
              src={selectedImage} 
              alt="Selected decoration" 
              className="max-w-full max-h-full object-contain"
              onError={(e) => {
                e.currentTarget.src = '/placeholder-image.jpg';
                e.currentTarget.alt = 'Image not available';
              }}
            />
            <button 
              className="absolute top-4 right-4 text-white bg-black bg-opacity-50 rounded-full p-2 hover:bg-opacity-75 transition"
              onClick={() => setSelectedImage(null)}
            >
              Close
            </button>
          </motion.div>
        </div>
      )}

      <Footer />
    </div>
  );
}
